Cutline – install as a phone app
1. Upload this whole folder to any free HTTPS host (Netlify Drop, Cloudflare Pages, GitHub Pages).
2. Open the link in Chrome on your phone.
3. Menu (three dots) > Install app / Add to Home screen.
